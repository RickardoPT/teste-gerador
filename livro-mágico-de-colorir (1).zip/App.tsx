import React, { useState, useEffect, useRef } from 'react';
import { 
  Palette, Menu, X, PlusCircle, Book, Settings as SettingsIcon, 
  Database, Users, BookOpen, Trash2, Calendar, Download, Upload, 
  Save, Trash, Mail, Plus, Edit2, Search, RefreshCw, ChevronLeft, 
  ChevronRight, Sparkles, PenTool, Smile, Grid3X3, Layers, Crown, 
  SlidersHorizontal, ChevronDown, ChevronUp, MessageCircle, Send, Loader2 
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { jsPDF } from 'jspdf';

// ==========================================
// 1. TYPES & INTERFACES
// ==========================================

interface ColoringPage {
  id: string;
  url: string; // Base64 data URL
  prompt: string;
  isCover: boolean;
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

interface Client {
  id: string;
  name: string;
  email: string;
  notes: string;
  createdAt: string;
}

interface SavedBook {
  id: string;
  title: string; // Theme
  childName: string;
  date: string;
  pages: ColoringPage[];
  style: string | string[];
  pageCount: number;
}

type ViewMode = 'generator' | 'library' | 'settings' | 'clients';

interface AppState {
  currentView: ViewMode;
  savedBooks: SavedBook[];
  clients: Client[];
  // Generator State
  theme: string;
  childName: string;
  style: string | string[];
  pageCount: number;
  isGenerating: boolean;
  pages: ColoringPage[];
  generationProgress: number; // 0 to 100
  error: string | null;
  // Extra inputs
  lineThickness: 'thin' | 'medium' | 'thick';
  referenceInput: string;
}

// ==========================================
// 2. GEMINI SERVICE LOGIC
// ==========================================

// Initialize the client safely
// We check for process.env.API_KEY which is polyfilled in vite.config.ts or import.meta.env
const apiKey = process.env.API_KEY || (import.meta as any).env?.VITE_API_KEY || '';
const ai = new GoogleGenAI({ apiKey: apiKey });

const generateColoringBookPages = async (
  theme: string,
  childName: string,
  styles: string | string[], 
  thickness: 'thin' | 'medium' | 'thick',
  reference: string,
  pageCount: number,
  onProgress: (completed: number, total: number) => void
): Promise<ColoringPage[]> => {
  
  if (!apiKey) {
    throw new Error("Chave de API não configurada. Por favor configure a API_KEY no Vercel.");
  }

  const totalPages = pageCount; 
  const generatedPages: ColoringPage[] = [];

  const thicknessDesc = {
    'thin': 'thin fine lines',
    'medium': 'thick lines',
    'thick': 'very thick bold outlines'
  }[thickness] || 'thick lines';

  const referenceText = reference ? ` context: ${reference}.` : '';

  // Map style ID to prompt descriptor
  const styleDescriptors: Record<string, string> = {
    'cartoon': 'cute cartoon style, rounded shapes',
    'realistic': 'realistic sketch style, detailed',
    'kawaii': 'kawaii chibi style, very cute, large eyes',
    'pixel': 'pixel art style, 8-bit retro',
    'mandala': 'mandala pattern style, intricate details, geometric'
  };

  const getStylePrompt = (index: number): string => {
    const styleId = Array.isArray(styles) ? styles[index % styles.length] : styles;
    return styleDescriptors[styleId] || 'children\'s book illustration style';
  };

  try {
    // 1. Generate Cover (Index 0)
    const currentStylePrompt = getStylePrompt(0);
    const coverPrompt = `A children's coloring book cover page featuring ${theme} in ${currentStylePrompt}. Clean black and white line art, ${thicknessDesc}, vector style, white background, no shading. Leave space in the center for a title. Cute and welcoming.${referenceText}`;
    
    const coverResponse = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: coverPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/png',
        aspectRatio: '3:4',
      },
    });

    if (coverResponse.generatedImages?.[0]?.image?.imageBytes) {
      generatedPages.push({
        id: 'cover',
        url: `data:image/png;base64,${coverResponse.generatedImages[0].image.imageBytes}`,
        prompt: coverPrompt,
        isCover: true,
      });
    }
    onProgress(1, totalPages);

    // 2. Generate Internal Pages
    const pagePromptsTemplates = [
      (s: string) => `A simple coloring page of ${theme} doing a fun activity, ${s}. Black and white line art, ${thicknessDesc}, simple for kids.${referenceText}`,
      (s: string) => `A close-up character portrait related to ${theme}, ${s}. Coloring book style, black and white, high contrast.${referenceText}`,
      (s: string) => `A landscape or scene showing the world of ${theme}, ${s}. Simple outlines, black and white, coloring book page, ${thicknessDesc}.${referenceText}`,
      (s: string) => `A funny or cute moment involving ${theme}, ${s}. Thick vector lines, black and white, no shading.${referenceText}`,
      (s: string) => `A pattern or collection of items related to ${theme}, ${s}. Coloring book style, black and white, ${thicknessDesc}.${referenceText}`
    ];

    for (let i = 1; i < pageCount; i++) {
      const templateIndex = (i - 1) % pagePromptsTemplates.length;
      const pageStylePrompt = getStylePrompt(i);
      const prompt = pagePromptsTemplates[templateIndex](pageStylePrompt);

      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '3:4',
        },
      });

      if (response.generatedImages?.[0]?.image?.imageBytes) {
        generatedPages.push({
          id: `page-${i}`,
          url: `data:image/png;base64,${response.generatedImages[0].image.imageBytes}`,
          prompt: prompt,
          isCover: false,
        });
      }
      onProgress(i + 1, totalPages);
    }

    return generatedPages;

  } catch (error) {
    console.error("Error generating images:", error);
    throw new Error("Falha ao gerar as imagens. Verifique a Chave da API ou tente novamente.");
  }
};

const createChatSession = () => {
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "És um assistente amigável e criativo chamado 'Mestre das Cores'. O teu objetivo é ajudar pais e crianças a terem ideias para livros de colorir. Fala sempre em Português de Portugal (pt-PT). Sê breve, divertido e encorajador.",
    },
  });
};

// ==========================================
// 3. COMPONENTS
// ==========================================

// --- ChatWidget Component ---
const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Olá! Precisas de ajuda para escolher um tema?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatSessionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && !chatSessionRef.current && apiKey) {
      chatSessionRef.current = createChatSession();
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !chatSessionRef.current || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response = await chatSessionRef.current.sendMessage({ message: userMsg });
      const responseText = response.text;
      if (responseText) {
        setMessages(prev => [...prev, { role: 'model', text: responseText }]);
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Desculpa, tive um problema. Tenta novamente.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!apiKey) return null; // Hide chat if no API key

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {isOpen && (
        <div className="mb-4 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-indigo-100 overflow-hidden flex flex-col h-[500px] transition-all animate-in fade-in slide-in-from-bottom-10">
          <div className="bg-indigo-600 p-4 flex justify-between items-center text-white">
            <div className="flex items-center gap-2">
              <MessageCircle size={20} />
              <h3 className="font-bold">Assistente Criativo</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-indigo-700 p-1 rounded transition">
              <X size={20} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                  msg.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                    : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none shadow-sm'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-tl-none shadow-sm">
                  <Loader2 className="animate-spin text-indigo-600" size={16} />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-3 bg-white border-t border-gray-100 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Escreve uma mensagem..."
              className="flex-1 border border-gray-200 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
            <button onClick={handleSend} disabled={!input.trim() || isLoading} className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white p-2 rounded-full transition-colors">
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
      <button onClick={() => setIsOpen(!isOpen)} className={`${isOpen ? 'bg-gray-500' : 'bg-indigo-600 hover:bg-indigo-700 hover:scale-105'} text-white p-4 rounded-full shadow-lg transition-all duration-200 flex items-center gap-2 font-semibold`}>
        {!isOpen && <span className="hidden sm:block">Ajuda com Ideias</span>}
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </div>
  );
};

// --- Sidebar Component ---
const Sidebar: React.FC<{ isOpen: boolean; onClose: () => void; currentView: ViewMode; onNavigate: (view: ViewMode) => void; }> = ({ isOpen, onClose, currentView, onNavigate }) => {
  const handleNav = (view: ViewMode) => { onNavigate(view); onClose(); };
  
  const MenuItem = ({ icon: Icon, label, active, onClick }: any) => (
    <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium ${active ? 'bg-indigo-50 text-indigo-700 shadow-sm ring-1 ring-indigo-100' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}`}>
      <Icon size={20} strokeWidth={active ? 2.5 : 2} />
      {label}
    </button>
  );

  return (
    <>
      <div className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-50 transition-opacity duration-300 ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`} onClick={onClose} />
      <aside className={`fixed top-0 left-0 h-full w-72 bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="h-20 bg-indigo-600 flex items-center justify-between px-6 text-white">
          <div className="font-bold text-xl tracking-wide">Ferramenta Pessoal</div>
          <button onClick={onClose} className="p-2 hover:bg-indigo-700 rounded-full transition-colors"><X size={24} /></button>
        </div>
        <div className="p-4 py-6 flex flex-col h-[calc(100%-5rem)] justify-between">
          <nav className="space-y-2">
            <MenuItem icon={PlusCircle} label="Criar Novo Livro" active={currentView === 'generator'} onClick={() => handleNav('generator')} />
            <MenuItem icon={Book} label="Minha Biblioteca" active={currentView === 'library'} onClick={() => handleNav('library')} />
            <MenuItem icon={Users} label="Gestão de Clientes" active={currentView === 'clients'} onClick={() => handleNav('clients')} />
            <MenuItem icon={SettingsIcon} label="Definições & Backup" active={currentView === 'settings'} onClick={() => handleNav('settings')} />
          </nav>
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 text-xs text-gray-500">
             <div className="flex items-center gap-2 mb-2 font-bold text-gray-700"><Database size={14} /> Estado Local</div>
             <p>Os seus projetos são guardados localmente neste navegador.</p>
          </div>
        </div>
      </aside>
    </>
  );
};

// --- Clients Component ---
const Clients: React.FC<{ clients: Client[]; onAddClient: (c: Client) => void; onDeleteClient: (id: string) => void; }> = ({ clients, onAddClient, onDeleteClient }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNotes, setNewNotes] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    onAddClient({ id: Date.now().toString(), name: newName, email: newEmail, notes: newNotes, createdAt: new Date().toISOString() });
    setIsAdding(false); setNewName(''); setNewEmail(''); setNewNotes('');
  };

  const filtered = clients.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.email.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div><h2 className="text-3xl font-bold text-gray-900">Gestão de Clientes</h2><p className="text-gray-600">Gere a tua lista de clientes.</p></div>
        <button onClick={() => setIsAdding(!isAdding)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-200 transition-all"><Plus size={20} /> Adicionar Cliente</button>
      </div>
      {isAdding && (
        <div className="mb-8 bg-white p-6 rounded-2xl border border-indigo-100 shadow-lg">
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="Nome" value={newName} onChange={e => setNewName(e.target.value)} className="px-4 py-3 rounded-xl bg-gray-50 border outline-none" required />
            <input type="email" placeholder="Email" value={newEmail} onChange={e => setNewEmail(e.target.value)} className="px-4 py-3 rounded-xl bg-gray-50 border outline-none" />
            <input type="text" placeholder="Notas" value={newNotes} onChange={e => setNewNotes(e.target.value)} className="px-4 py-3 rounded-xl bg-gray-50 border outline-none md:col-span-2" />
            <div className="md:col-span-2 flex justify-end gap-2">
              <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 text-gray-500">Cancelar</button>
              <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg">Salvar</button>
            </div>
          </form>
        </div>
      )}
      <div className="mb-6 relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} /><input type="text" placeholder="Pesquisar..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 outline-none" /></div>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left"><thead className="bg-gray-50"><tr className="text-gray-600 text-sm"><th className="p-4">Nome</th><th className="p-4">Contacto</th><th className="p-4">Notas</th><th className="p-4 text-right">Ações</th></tr></thead>
          <tbody className="divide-y divide-gray-100">
            {filtered.length === 0 ? <tr><td colSpan={4} className="p-8 text-center text-gray-500">Sem registos.</td></tr> : filtered.map(c => (
              <tr key={c.id} className="hover:bg-gray-50"><td className="p-4 font-bold">{c.name}</td><td className="p-4 text-sm">{c.email || '-'}</td><td className="p-4 text-sm">{c.notes}</td><td className="p-4 text-right"><button onClick={() => {if(window.confirm('Apagar?')) onDeleteClient(c.id)}} className="text-gray-400 hover:text-red-500"><Trash2 size={18} /></button></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- Library Component ---
const Library: React.FC<{ books: SavedBook[]; onLoadBook: (b: SavedBook) => void; onDeleteBook: (id: string) => void; }> = ({ books, onLoadBook, onDeleteBook }) => {
  if (books.length === 0) return <div className="text-center py-20"><BookOpen size={48} className="text-indigo-300 mx-auto mb-4" /><h3 className="text-2xl font-bold text-gray-800">Biblioteca Vazia</h3></div>;
  return (
    <div className="max-w-7xl mx-auto px-4 pb-12">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Minha Biblioteca</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {books.map(book => (
          <div key={book.id} className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden group flex flex-col">
            <div className="aspect-[3/4] bg-gray-100 relative cursor-pointer overflow-hidden" onClick={() => onLoadBook(book)}>
              {book.pages[0]?.url ? <img src={book.pages[0].url} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" /> : <div className="flex items-center justify-center h-full"><BookOpen size={40} /></div>}
            </div>
            <div className="p-4 flex-1 flex flex-col">
              <h3 className="font-bold text-lg text-gray-800 line-clamp-1">{book.title}</h3>
              <p className="text-sm text-indigo-600 font-medium">{book.childName}</p>
              <div className="mt-auto pt-4 border-t border-gray-100 flex justify-between items-center">
                <div className="flex items-center gap-1 text-xs text-gray-400"><Calendar size={12} />{new Date(book.date).toLocaleDateString()}</div>
                <button onClick={(e) => {e.stopPropagation(); if(window.confirm('Apagar?')) onDeleteBook(book.id)}} className="text-gray-400 hover:text-red-500"><Trash2 size={18} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Settings Component ---
const Settings: React.FC<{ fullState: AppState; onImport: (d: any) => void; onClearData: () => void; }> = ({ fullState, onImport, onClearData }) => {
  const handleExport = () => {
    const dataStr = JSON.stringify(fullState.savedBooks, null, 2);
    const link = document.createElement('a');
    link.href = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    link.download = `backup_${new Date().toISOString().slice(0,10)}.json`;
    link.click();
  };
  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const reader = new FileReader();
    if (e.target.files?.[0]) {
      reader.readAsText(e.target.files[0]);
      reader.onload = ev => {
        try {
          const parsed = JSON.parse(ev.target?.result as string);
          if(Array.isArray(parsed) || parsed.savedBooks) { onImport(parsed); alert('Sucesso!'); }
        } catch { alert('Erro no ficheiro.'); }
      };
    }
  };
  return (
    <div className="max-w-2xl mx-auto px-4">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Definições</h2>
      <div className="bg-white rounded-2xl border border-gray-200 mb-8 overflow-hidden">
        <div className="p-6 border-b border-gray-100"><h3 className="font-bold flex gap-2"><Save className="text-indigo-600"/> Backup</h3></div>
        <div className="p-6 space-y-4">
          <div className="flex justify-between items-center bg-gray-50 p-4 rounded-xl"><div>Exportar</div><button onClick={handleExport} className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex gap-2"><Download size={18}/> Baixar</button></div>
          <div className="flex justify-between items-center bg-gray-50 p-4 rounded-xl"><div>Importar</div><label className="bg-white border px-4 py-2 rounded-lg cursor-pointer flex gap-2"><Upload size={18}/> JSON <input type="file" className="hidden" accept=".json" onChange={handleFileImport}/></label></div>
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-red-100 overflow-hidden">
        <div className="p-6 bg-red-50/30 border-b border-red-50"><h3 className="font-bold text-red-800 flex gap-2"><Trash/> Danger Zone</h3></div>
        <div className="p-6 flex justify-between items-center"><div>Limpar Tudo</div><button onClick={onClearData} className="text-red-600 border border-red-200 px-4 py-2 rounded-lg">Reset Dados</button></div>
      </div>
    </div>
  );
};

// --- Generator Component ---
const DRAWING_STYLES = [
  { id: 'cartoon', label: 'Desenho Animado', icon: Smile, description: 'Estilo divertido com formas arredondadas.' },
  { id: 'realistic', label: 'Realista', icon: PenTool, description: 'Detalhado com proporções reais.' },
  { id: 'kawaii', label: 'Fofo / Kawaii', icon: Sparkles, description: 'Estilo japonês adorável.' },
  { id: 'pixel', label: 'Pixel Art', icon: Grid3X3, description: 'Arte digital retro 8-bit.' },
  { id: 'mandala', label: 'Padrões', icon: Palette, description: 'Formas geométricas intrincadas.' },
];

const Generator: React.FC<any> = ({ onGenerate, onDraftChange, isGenerating, progress, error, initialValues }) => {
  const [theme, setTheme] = useState(initialValues?.theme || '');
  const [name, setName] = useState(initialValues?.childName || '');
  const [isAdvancedMode, setIsAdvancedMode] = useState(Array.isArray(initialValues?.style));
  const [globalStyle, setGlobalStyle] = useState(!Array.isArray(initialValues?.style) ? (initialValues?.style || 'cartoon') : 'cartoon');
  const [pageCount, setPageCount] = useState(initialValues?.pageCount || 6);
  const [pageStyles, setPageStyles] = useState<string[]>(Array.isArray(initialValues?.style) ? initialValues.style : Array(12).fill('cartoon'));
  const [thickness, setThickness] = useState(initialValues?.lineThickness || 'medium');
  const [reference, setReference] = useState(initialValues?.referenceInput || '');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    onDraftChange('theme', theme);
    onDraftChange('childName', name);
    onDraftChange('style', isAdvancedMode ? pageStyles.slice(0, pageCount) : globalStyle);
    onDraftChange('lineThickness', thickness);
    onDraftChange('referenceInput', reference);
    onDraftChange('pageCount', pageCount);
  }, [theme, name, globalStyle, pageStyles, thickness, reference, pageCount, isAdvancedMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (theme && name) onGenerate(theme, name, isAdvancedMode ? pageStyles.slice(0, pageCount) : globalStyle, thickness, reference, pageCount);
  };

  const updatePageStyle = (idx: number, val: string) => {
    const n = [...pageStyles]; n[idx] = val; setPageStyles(n);
  };

  if (isGenerating) {
    return (
      <div className="max-w-md mx-auto text-center py-12 px-4">
        <div className="relative w-32 h-32 mx-auto mb-8"><div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div><div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div><div className="absolute inset-0 flex items-center justify-center"><Sparkles className="text-indigo-600 animate-pulse" size={32} /></div></div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">A criar magia...</h3>
        <p className="text-gray-600 mb-6">Página {Math.floor((progress / 100) * pageCount)} de {pageCount}</p>
        <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden"><div className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl border border-indigo-50 p-8 sm:p-12">
      <div className="text-center mb-10">
        <div className="bg-indigo-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-indigo-600"><BookOpen size={32} /></div>
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Cria o teu Livro</h2>
      </div>
      {!apiKey && <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-xl mb-6 text-sm">⚠️ Aviso: A API KEY não foi detetada. A geração falhará. Por favor configure no Vercel.</div>}
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-6">
          <div><label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Nome da Criança</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Matilde" className="w-full px-6 py-4 rounded-2xl bg-gray-800 text-white placeholder-gray-400 outline-none" required /></div>
          <div><label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Tema do Livro</label><input type="text" value={theme} onChange={(e) => setTheme(e.target.value)} placeholder="Ex: Dinossauros no Espaço..." className="w-full px-6 py-4 rounded-2xl bg-gray-800 text-white placeholder-gray-400 outline-none" required /></div>
        </div>
        <div>
          <div className="flex justify-between items-center mb-4 px-1"><label className="block text-sm font-bold text-gray-700">Estilo</label><div className="flex bg-gray-100 p-1 rounded-lg"><button type="button" onClick={() => setIsAdvancedMode(false)} className={`px-3 py-1.5 text-xs font-bold rounded-md ${!isAdvancedMode ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}>Uniforme</button><button type="button" onClick={() => setIsAdvancedMode(true)} className={`px-3 py-1.5 text-xs font-bold rounded-md flex items-center gap-1 ${isAdvancedMode ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}><Layers size={12} /> Misto</button></div></div>
          {!isAdvancedMode ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">{DRAWING_STYLES.map((s) => { const Icon = s.icon; const sel = globalStyle === s.id; return ( <button key={s.id} type="button" onClick={() => setGlobalStyle(s.id)} className={`group relative flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all ${sel ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 bg-white text-gray-500'}`}><Icon size={24} className="mb-2" /><span className="text-xs font-bold">{s.label}</span></button> ); })}</div>
          ) : (
            <div className="space-y-3 bg-gray-50 p-4 rounded-2xl border border-gray-100"><div className="flex items-center gap-2 text-xs text-indigo-600 font-bold mb-2 bg-indigo-50 p-2 rounded-lg inline-block"><Crown size={12} /> Avançado</div>{Array.from({ length: pageCount }).map((_, idx) => (<div key={idx} className="flex items-center justify-between bg-white p-3 rounded-xl border border-gray-200"><span className="text-xs font-bold text-gray-500 w-16">{idx === 0 ? 'Capa' : `Pág ${idx}`}</span><select value={pageStyles[idx]} onChange={(e) => updatePageStyle(idx, e.target.value)} className="bg-gray-50 border-2 border-gray-100 text-gray-700 text-sm rounded-lg p-2 w-full">{DRAWING_STYLES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}</select></div>))}</div>
          )}
        </div>
        <div className="border border-gray-200 rounded-2xl overflow-hidden">
            <button type="button" onClick={() => setShowFilters(!showFilters)} className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold text-sm"><div className="flex items-center gap-2"><SlidersHorizontal size={16} /> Mais Opções</div>{showFilters ? <ChevronUp size={16} /> : <ChevronDown size={16} />}</button>
            {showFilters && (
                <div className="p-4 bg-white space-y-6">
                    <div><div className="flex justify-between items-center mb-2"><label className="text-xs font-bold text-gray-600">Páginas</label><span className="bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded text-xs font-bold">{pageCount}</span></div><input type="range" min="3" max="12" value={pageCount} onChange={(e) => setPageCount(parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" /></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-gray-100">
                        <div><label className="block text-xs font-bold text-gray-600 mb-1.5">Espessura</label><div className="flex bg-gray-100 p-1 rounded-lg">{(['thin', 'medium', 'thick'] as const).map((t) => (<button key={t} type="button" onClick={() => setThickness(t)} className={`flex-1 py-1.5 text-xs font-bold rounded-md capitalize ${thickness === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}>{t === 'thin' ? 'Fina' : t === 'medium' ? 'Média' : 'Grossa'}</button>))}</div></div>
                        <div><label className="block text-xs font-bold text-gray-600 mb-1.5">Contexto Extra</label><input type="text" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Ex: balões..." className="w-full px-3 py-1.5 text-sm rounded-lg bg-gray-50 border border-gray-200 outline-none" /></div>
                    </div>
                </div>
            )}
        </div>
        {error && <div className="bg-red-50 text-red-600 p-4 rounded-xl text-sm border border-red-100">{error}</div>}
        <button type="submit" disabled={!theme || !name} className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 text-lg"><Sparkles size={24} /> Gerar Livro</button>
      </form>
    </div>
  );
};

// --- Results Component ---
const Results: React.FC<{ pages: ColoringPage[]; childName: string; theme: string; onReset: () => void; }> = ({ pages, childName, theme, onReset }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const generatePDF = () => {
    setIsDownloading(true);
    try {
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      pages.forEach((page, index) => {
        if (index > 0) doc.addPage();
        const imgWidth = 190; const imgHeight = 250;
        doc.addImage(page.url, 'PNG', 10, 20, imgWidth, imgHeight, undefined, 'FAST');
        doc.setFont("helvetica", "bold"); doc.setTextColor(0, 0, 0);
        if (page.isCover) { doc.setFontSize(24); doc.text("Livro de Colorir", 105, 30, { align: 'center' }); doc.setFontSize(40); doc.text(childName, 105, 270, { align: 'center' }); doc.setFontSize(16); doc.setFont("helvetica", "normal"); doc.text(theme, 105, 285, { align: 'center' }); }
        else { doc.setFontSize(10); doc.text(`Página ${index}`, 105, 290, { align: 'center' }); }
        doc.setFontSize(9); doc.setTextColor(100, 100, 100); doc.text("Criado com Livro Mágico", 105, 295, { align: 'center' });
      });
      doc.save(`Livro_${childName}.pdf`);
    } catch (err) { alert("Erro PDF"); } finally { setIsDownloading(false); }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div><h2 className="text-3xl font-bold text-gray-900">Livro Pronto!</h2><p className="text-gray-600">Desliza para ver as páginas.</p></div>
        <div className="flex gap-3"><button onClick={onReset} className="px-6 py-3 bg-white border border-gray-200 text-gray-700 font-semibold rounded-xl flex items-center gap-2"><RefreshCw size={20} /> Novo</button><button onClick={generatePDF} disabled={isDownloading} className="px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-lg flex items-center gap-2">{isDownloading ? 'A Gerar...' : <><Download size={20} /> PDF</>}</button></div>
      </div>
      <div className="flex flex-col items-center">
        <div className="relative w-full max-w-md aspect-[3/4] bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden mb-6 group">
          <img src={pages[currentIndex].url} className="w-full h-full object-contain bg-white" />
          {pages[currentIndex].isCover && <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 text-center"><div className="mt-4"><span className="bg-white/90 px-4 py-2 rounded-full text-sm font-bold text-black shadow-md border">LIVRO DE COLORIR</span></div><div className="mb-8"><h3 className="text-4xl font-black text-black bg-white/80 inline-block px-6 py-3 rounded-2xl border">{childName}</h3></div></div>}
          <button onClick={() => setCurrentIndex(p => p === 0 ? pages.length - 1 : p - 1)} className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 hover:scale-110"><ChevronLeft size={24} /></button>
          <button onClick={() => setCurrentIndex(p => p === pages.length - 1 ? 0 : p + 1)} className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 hover:scale-110"><ChevronRight size={24} /></button>
        </div>
        <div className="flex gap-3 overflow-x-auto max-w-full p-2 pb-4">{pages.map((page, idx) => (<button key={page.id} onClick={() => setCurrentIndex(idx)} className={`relative w-16 h-20 rounded-lg overflow-hidden border-2 flex-shrink-0 ${currentIndex === idx ? 'border-indigo-600 ring-2 ring-indigo-200 scale-110 z-10' : 'border-gray-200 opacity-60'}`}><img src={page.url} className="w-full h-full object-cover" />{idx === 0 && <div className="absolute inset-0 flex items-center justify-center bg-black/20 text-white text-[8px] font-bold">CAPA</div>}</button>))}</div>
      </div>
    </div>
  );
};

// ==========================================
// 4. MAIN APP COMPONENT
// ==========================================

const STORAGE_KEY = 'livro_magico_personal_tool_v2';

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...parsed, isGenerating: false, generationProgress: 0, error: null, savedBooks: parsed.savedBooks || [], clients: parsed.clients || [], currentView: parsed.currentView || 'generator', pageCount: parsed.pageCount || 6 };
      }
    } catch (e) { console.error(e); }
    return { currentView: 'generator', savedBooks: [], clients: [], theme: '', childName: '', style: 'cartoon', pageCount: 6, isGenerating: false, pages: [], generationProgress: 0, error: null, lineThickness: 'medium', referenceInput: '' };
  });

  useEffect(() => {
    const stateToSave = { ...state, isGenerating: false, generationProgress: 0, error: null };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
  }, [state]);

  const handleDraftChange = (field: string, value: any) => { setState(prev => ({ ...prev, [field]: value })); };
  
  const handleGenerate = async (theme: string, name: string, style: string | string[], thickness: 'thin' | 'medium' | 'thick', reference: string, pageCount: number) => {
    setState(prev => ({ ...prev, theme, childName: name, style, lineThickness: thickness, referenceInput: reference, pageCount, isGenerating: true, generationProgress: 0, error: null, pages: [] }));
    try {
      const pages = await generateColoringBookPages(theme, name, style, thickness, reference, pageCount, (completed, total) => {
        setState(prev => ({ ...prev, generationProgress: (completed / total) * 100 }));
      });
      const newBook: SavedBook = { id: Date.now().toString(), title: theme, childName: name, date: new Date().toISOString(), pages, style, pageCount };
      setState(prev => ({ ...prev, isGenerating: false, pages, savedBooks: [newBook, ...prev.savedBooks] }));
    } catch (error: any) {
      setState(prev => ({ ...prev, isGenerating: false, error: error.message }));
    }
  };

  const renderContent = () => {
    if (state.currentView === 'settings') return <Settings fullState={state} onImport={(d: any) => { if(Array.isArray(d)) setState(p => ({...p, savedBooks: [...d, ...p.savedBooks]})) }} onClearData={() => { localStorage.removeItem(STORAGE_KEY); window.location.reload(); }} />;
    if (state.currentView === 'library') return <Library books={state.savedBooks} onLoadBook={(b) => setState(p => ({...p, pages: b.pages, theme: b.title, childName: b.childName, style: b.style, pageCount: b.pageCount || 6, currentView: 'generator'}))} onDeleteBook={(id) => setState(p => ({...p, savedBooks: p.savedBooks.filter(x => x.id !== id)}))} />;
    if (state.currentView === 'clients') return <Clients clients={state.clients} onAddClient={(c) => setState(p => ({...p, clients: [c, ...p.clients]}))} onDeleteClient={(id) => setState(p => ({...p, clients: p.clients.filter(x => x.id !== id)}))} />;
    if (state.pages.length > 0) return <Results pages={state.pages} childName={state.childName} theme={state.theme} onReset={() => setState(p => ({...p, pages: [], isGenerating: false, error: null}))} />;
    return <Generator onGenerate={handleGenerate} onDraftChange={handleDraftChange} isGenerating={state.isGenerating} progress={state.generationProgress} error={state.error} initialValues={{ theme: state.theme, childName: state.childName, style: state.style, lineThickness: state.lineThickness, referenceInput: state.referenceInput, pageCount: state.pageCount }} />;
  };

  return (
    <div className="min-h-screen bg-[#f0f9ff] bg-[radial-gradient(#e0f2fe_1px,transparent_1px)] [background-size:20px_20px] text-gray-800 font-sans">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} currentView={state.currentView} onNavigate={(v) => setState(p => ({...p, currentView: v}))} />
      <header className="bg-white/90 backdrop-blur-md border-b border-indigo-100 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4"><button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-gray-100 rounded-full"><Menu size={24} /></button><div className="flex items-center gap-2 cursor-pointer" onClick={() => setState(p => ({...p, currentView: 'generator'}))}><div className="bg-indigo-600 p-1.5 rounded-lg text-white transform -rotate-6"><Palette size={20} /></div><h1 className="text-xl font-extrabold text-indigo-600">Livro Mágico</h1></div></div>
          <div className="text-sm font-medium text-gray-500 hidden sm:block capitalize">{state.currentView}</div>
        </div>
      </header>
      <main className="pt-8 md:pt-12 min-h-[calc(100vh-64px)]">{renderContent()}</main>
      <ChatWidget />
    </div>
  );
};

export default App;
