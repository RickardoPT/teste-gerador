import { GoogleGenAI, Modality } from "@google/genai";
import { ColoringPage } from "../types";

// Initialize the client with the API key from environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateColoringBookPages = async (
  theme: string,
  childName: string,
  styles: string | string[], // Changed to accept single style or array
  thickness: 'thin' | 'medium' | 'thick',
  reference: string,
  pageCount: number,
  onProgress: (completed: number, total: number) => void
): Promise<ColoringPage[]> => {
  const totalPages = pageCount; 
  const generatedPages: ColoringPage[] = [];

  const thicknessDesc = {
    'thin': 'thin fine lines',
    'medium': 'thick lines',
    'thick': 'very thick bold outlines'
  }[thickness] || 'thick lines';

  const referenceText = reference ? ` context: ${reference}.` : '';

  // Map style ID to prompt descriptor
  const styleDescriptors: Record<string, string> = {
    'cartoon': 'cute cartoon style, rounded shapes',
    'realistic': 'realistic sketch style, detailed',
    'kawaii': 'kawaii chibi style, very cute, large eyes',
    'pixel': 'pixel art style, 8-bit retro',
    'mandala': 'mandala pattern style, intricate details, geometric'
  };

  const getStylePrompt = (index: number): string => {
    const styleId = Array.isArray(styles) ? styles[index % styles.length] : styles;
    return styleDescriptors[styleId] || 'children\'s book illustration style';
  };

  // 1. Generate Cover (Index 0)
  try {
    const currentStylePrompt = getStylePrompt(0);
    const coverPrompt = `A children's coloring book cover page featuring ${theme} in ${currentStylePrompt}. Clean black and white line art, ${thicknessDesc}, vector style, white background, no shading. Leave space in the center for a title. Cute and welcoming.${referenceText}`;
    
    const coverResponse = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: coverPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/png',
        aspectRatio: '3:4', // Portrait for book page
      },
    });

    if (coverResponse.generatedImages?.[0]?.image?.imageBytes) {
      generatedPages.push({
        id: 'cover',
        url: `data:image/png;base64,${coverResponse.generatedImages[0].image.imageBytes}`,
        prompt: coverPrompt,
        isCover: true,
      });
    }
    onProgress(1, totalPages);

    // 2. Generate Internal Pages
    const pagePromptsTemplates = [
      (s: string) => `A simple coloring page of ${theme} doing a fun activity, ${s}. Black and white line art, ${thicknessDesc}, simple for kids.${referenceText}`,
      (s: string) => `A close-up character portrait related to ${theme}, ${s}. Coloring book style, black and white, high contrast.${referenceText}`,
      (s: string) => `A landscape or scene showing the world of ${theme}, ${s}. Simple outlines, black and white, coloring book page, ${thicknessDesc}.${referenceText}`,
      (s: string) => `A funny or cute moment involving ${theme}, ${s}. Thick vector lines, black and white, no shading.${referenceText}`,
      (s: string) => `A pattern or collection of items related to ${theme}, ${s}. Coloring book style, black and white, ${thicknessDesc}.${referenceText}`
    ];

    // We start loop at 1 because 0 was cover. Loop until we reach pageCount.
    for (let i = 1; i < pageCount; i++) {
      // Use modulo to cycle through prompt templates if pageCount > available templates
      const templateIndex = (i - 1) % pagePromptsTemplates.length;
      
      const pageStylePrompt = getStylePrompt(i);
      const prompt = pagePromptsTemplates[templateIndex](pageStylePrompt);

      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '3:4',
        },
      });

      if (response.generatedImages?.[0]?.image?.imageBytes) {
        generatedPages.push({
          id: `page-${i}`,
          url: `data:image/png;base64,${response.generatedImages[0].image.imageBytes}`,
          prompt: prompt,
          isCover: false,
        });
      }
      onProgress(i + 1, totalPages);
    }

    return generatedPages;

  } catch (error) {
    console.error("Error generating images:", error);
    throw new Error("Falha ao gerar as imagens. Por favor, tente novamente.");
  }
};

export const createChatSession = () => {
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "És um assistente amigável e criativo chamado 'Mestre das Cores'. O teu objetivo é ajudar pais e crianças a terem ideias para livros de colorir. Fala sempre em Português de Portugal (pt-PT). Sê breve, divertido e encorajador. Sugere temas se o utilizador estiver sem ideias.",
    },
  });
};