import React from 'react';
import { X, PlusCircle, Book, Settings, Database, Users } from 'lucide-react';
import { ViewMode } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentView: ViewMode;
  onNavigate: (view: ViewMode) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, currentView, onNavigate }) => {
  
  const handleNav = (view: ViewMode) => {
    onNavigate(view);
    onClose(); // Close sidebar on mobile after selection
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-50 transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Sidebar Panel */}
      <aside 
        className={`fixed top-0 left-0 h-full w-72 bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="h-20 bg-indigo-600 flex items-center justify-between px-6 text-white">
          <div className="font-bold text-xl tracking-wide">Ferramenta Pessoal</div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-indigo-700 rounded-full transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 py-6 flex flex-col h-[calc(100%-5rem)] justify-between">
          <nav className="space-y-2">
            <MenuItem 
              icon={PlusCircle} 
              label="Criar Novo Livro" 
              active={currentView === 'generator'} 
              onClick={() => handleNav('generator')}
            />
            <MenuItem 
              icon={Book} 
              label="Minha Biblioteca" 
              active={currentView === 'library'} 
              onClick={() => handleNav('library')}
            />
            <MenuItem 
              icon={Users} 
              label="Gestão de Clientes" 
              active={currentView === 'clients'} 
              onClick={() => handleNav('clients')}
            />
            <MenuItem 
              icon={Settings} 
              label="Definições & Backup" 
              active={currentView === 'settings'} 
              onClick={() => handleNav('settings')}
            />
          </nav>

          <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 text-xs text-gray-500">
             <div className="flex items-center gap-2 mb-2 font-bold text-gray-700">
                <Database size={14} />
                Estado Local
             </div>
             <p>Os seus projetos são guardados localmente neste navegador.</p>
          </div>
        </div>
      </aside>
    </>
  );
};

interface MenuItemProps {
  icon: React.ElementType;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ icon: Icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium ${
      active 
        ? 'bg-indigo-50 text-indigo-700 shadow-sm ring-1 ring-indigo-100' 
        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
    }`}
  >
    <Icon size={20} strokeWidth={active ? 2.5 : 2} />
    {label}
  </button>
);

export default Sidebar;