import React, { useState } from 'react';
import { Users, Plus, Trash2, Mail, Edit2, Search } from 'lucide-react';
import { Client } from '../types';

interface ClientsProps {
  clients: Client[];
  onAddClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
}

const Clients: React.FC<ClientsProps> = ({ clients, onAddClient, onDeleteClient }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form state
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNotes, setNewNotes] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const client: Client = {
      id: Date.now().toString(),
      name: newName,
      email: newEmail,
      notes: newNotes,
      createdAt: new Date().toISOString()
    };
    onAddClient(client);
    setIsAdding(false);
    setNewName('');
    setNewEmail('');
    setNewNotes('');
  };

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Gestão de Clientes</h2>
          <p className="text-gray-600">Gere a tua lista de clientes e pedidos.</p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-200 transition-all"
        >
          <Plus size={20} />
          Adicionar Cliente
        </button>
      </div>

      {/* Add Client Form */}
      {isAdding && (
        <div className="mb-8 bg-white p-6 rounded-2xl border border-indigo-100 shadow-lg animate-in fade-in slide-in-from-top-4">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Novo Registo</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Nome do Cliente"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              className="px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
            <input
              type="email"
              placeholder="Email (Opcional)"
              value={newEmail}
              onChange={e => setNewEmail(e.target.value)}
              className="px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <input
              type="text"
              placeholder="Notas / Pedidos"
              value={newNotes}
              onChange={e => setNewNotes(e.target.value)}
              className="px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none md:col-span-2"
            />
            <div className="md:col-span-2 flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg font-medium"
              >
                Cancelar
              </button>
              <button 
                type="submit"
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700"
              >
                Salvar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search Bar */}
      <div className="mb-6 relative">
         <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
         <input 
            type="text" 
            placeholder="Pesquisar clientes..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-200 outline-none"
         />
      </div>

      {/* Clients List */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="p-4 font-bold text-gray-600 text-sm">Nome</th>
                <th className="p-4 font-bold text-gray-600 text-sm">Contacto</th>
                <th className="p-4 font-bold text-gray-600 text-sm">Notas</th>
                <th className="p-4 font-bold text-gray-600 text-sm text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredClients.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-500">
                    Nenhum cliente encontrado.
                  </td>
                </tr>
              ) : (
                filteredClients.map((client) => (
                  <tr key={client.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="p-4">
                      <div className="font-bold text-gray-800">{client.name}</div>
                      <div className="text-xs text-gray-400">Adicionado: {new Date(client.createdAt).toLocaleDateString()}</div>
                    </td>
                    <td className="p-4">
                      {client.email ? (
                        <div className="flex items-center gap-2 text-gray-600 text-sm">
                          <Mail size={14} />
                          {client.email}
                        </div>
                      ) : <span className="text-gray-300 text-sm">-</span>}
                    </td>
                    <td className="p-4 text-sm text-gray-600 max-w-xs truncate">
                      {client.notes || <span className="text-gray-300 italic">Sem notas</span>}
                    </td>
                    <td className="p-4 text-right">
                      <button 
                        onClick={() => {
                            if(window.confirm('Apagar este cliente?')) onDeleteClient(client.id)
                        }}
                        className="text-gray-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Clients;