import React from 'react';
import { Download, Upload, Save, Trash } from 'lucide-react';
import { AppState } from '../types';

interface SettingsProps {
  fullState: AppState;
  onImport: (data: any) => void;
  onClearData: () => void;
}

const Settings: React.FC<SettingsProps> = ({ fullState, onImport, onClearData }) => {
  
  const handleExport = () => {
    const dataStr = JSON.stringify(fullState.savedBooks, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `backup_livro_magico_${new Date().toISOString().slice(0,10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files[0]) {
      fileReader.readAsText(event.target.files[0], "UTF-8");
      fileReader.onload = e => {
        if (e.target?.result) {
            try {
                const parsed = JSON.parse(e.target.result as string);
                if (Array.isArray(parsed)) {
                    onImport(parsed);
                    alert('Importação concluída com sucesso!');
                } else {
                    alert('Ficheiro inválido. O formato deve ser um array de livros.');
                }
            } catch (err) {
                alert('Erro ao ler o ficheiro JSON.');
            }
        }
      };
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900">Definições</h2>
        <p className="text-gray-600">Gestão de dados e backups da ferramenta.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
        <div className="p-6 border-b border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <Save size={20} className="text-indigo-600" />
            Backup & Restauro
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            Exporte a sua biblioteca de livros para um ficheiro JSON ou importe um backup anterior.
          </p>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
            <div>
              <div className="font-semibold text-gray-700">Exportar Biblioteca</div>
              <div className="text-xs text-gray-500">Guarda todos os teus projetos criados num ficheiro.</div>
            </div>
            <button 
              onClick={handleExport}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              <Download size={18} />
              Download Backup
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
            <div>
              <div className="font-semibold text-gray-700">Importar Biblioteca</div>
              <div className="text-xs text-gray-500">Restaura livros a partir de um backup.</div>
            </div>
            <label className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg font-medium transition-colors cursor-pointer shadow-sm">
              <Upload size={18} />
              Importar JSON
              <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
            </label>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-red-100 overflow-hidden">
        <div className="p-6 border-b border-red-50 bg-red-50/30">
          <h3 className="text-lg font-bold text-red-800 flex items-center gap-2">
            <Trash size={20} />
            Zona de Perigo
          </h3>
        </div>
        <div className="p-6">
           <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="font-semibold text-gray-800">Limpar Tudo</div>
              <div className="text-xs text-gray-500">Apaga todos os livros e reinicia a aplicação. Esta ação é irreversível.</div>
            </div>
            <button 
              onClick={onClearData}
              className="text-red-600 hover:bg-red-50 border border-red-200 hover:border-red-300 px-4 py-2 rounded-lg font-medium transition-all"
            >
              Limpar Dados
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;