import React, { useState } from 'react';
import { Download, RefreshCw, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { ColoringPage } from '../types';
import { jsPDF } from 'jspdf';

interface ResultsProps {
  pages: ColoringPage[];
  childName: string;
  theme: string;
  onReset: () => void;
}

const Results: React.FC<ResultsProps> = ({ pages, childName, theme, onReset }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const generatePDF = () => {
    setIsDownloading(true);
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = 210;
      const pageHeight = 297;
      const margin = 10;

      pages.forEach((page, index) => {
        if (index > 0) {
          doc.addPage();
        }

        // Add generated image
        const imgWidth = pageWidth - (margin * 2);
        const imgHeight = (pageHeight - (margin * 2)) * 0.85;

        doc.addImage(page.url, 'PNG', margin, margin + 10, imgWidth, imgHeight, undefined, 'FAST');

        // Add Text Overlay logic
        doc.setFont("helvetica", "bold");
        doc.setTextColor(0, 0, 0);

        if (page.isCover) {
          doc.setFontSize(24);
          doc.text("Livro de Colorir", pageWidth / 2, margin + 20, { align: 'center' });
          
          doc.setFontSize(40);
          doc.text(childName, pageWidth / 2, pageHeight - 40, { align: 'center' });
          
          doc.setFontSize(16);
          doc.setFont("helvetica", "normal");
          doc.text(`Tema: ${theme}`, pageWidth / 2, pageHeight - 25, { align: 'center' });
        } else {
           doc.setFontSize(10);
           doc.text(`Página ${index}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
        }

        // Footer with Website Link
        doc.setFontSize(9);
        doc.setTextColor(100, 100, 100);
        doc.text("Visite www.oseusite.com para mais livros!", pageWidth / 2, pageHeight - 5, { align: 'center' });
      });

      doc.save(`Livro_de_Colorir_${childName.replace(/\s+/g, '_')}.pdf`);
    } catch (err) {
      console.error("PDF Error", err);
      alert("Erro ao criar PDF. Tente novamente.");
    } finally {
      setIsDownloading(false);
    }
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === pages.length - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? pages.length - 1 : prev - 1));
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pb-20">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">O teu livro está pronto!</h2>
          <p className="text-gray-600">Usa as setas para ver todas as páginas.</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onReset}
            className="px-6 py-3 bg-white border border-gray-200 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition flex items-center gap-2"
          >
            <RefreshCw size={20} />
            Novo
          </button>
          <button
            onClick={generatePDF}
            disabled={isDownloading}
            className="px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition flex items-center gap-2"
          >
            {isDownloading ? (
              <span className="animate-pulse">A Preparar...</span>
            ) : (
              <>
                <Download size={20} />
                Baixar PDF
              </>
            )}
          </button>
        </div>
      </div>

      {/* Carousel Container */}
      <div className="flex flex-col items-center">
        <div className="relative w-full max-w-md aspect-[3/4] bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden mb-6 group">
          
          <img 
            src={pages[currentIndex].url} 
            alt={`Página ${currentIndex}`} 
            className="w-full h-full object-contain bg-white"
          />
          
          {/* Cover Overlay */}
          {pages[currentIndex].isCover && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 text-center">
              <div className="mt-4">
                <span className="bg-white/90 px-4 py-2 rounded-full text-sm font-bold text-black shadow-md backdrop-blur-sm uppercase tracking-widest border border-gray-100">
                  Livro de Colorir
                </span>
              </div>
              <div className="mb-8">
                <h3 className="text-4xl font-black text-black drop-shadow-lg bg-white/80 inline-block px-6 py-3 rounded-2xl backdrop-blur-md border border-gray-100">
                  {childName}
                </h3>
              </div>
            </div>
          )}

          {/* Navigation Arrows */}
          <button 
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 hover:scale-110"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 hover:scale-110"
          >
            <ChevronRight size={24} />
          </button>

          {/* Page Indicator */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-xs backdrop-blur-md">
             {currentIndex === 0 ? 'Capa' : `Página ${currentIndex} de ${pages.length - 1}`}
          </div>
        </div>

        {/* Thumbnails Strip */}
        <div className="flex gap-3 overflow-x-auto max-w-full p-2 pb-4">
          {pages.map((page, idx) => (
            <button
              key={page.id}
              onClick={() => setCurrentIndex(idx)}
              className={`relative w-16 h-20 rounded-lg overflow-hidden border-2 transition-all flex-shrink-0 ${
                currentIndex === idx ? 'border-indigo-600 ring-2 ring-indigo-200 scale-110 z-10' : 'border-gray-200 opacity-60 hover:opacity-100'
              }`}
            >
              <img src={page.url} className="w-full h-full object-cover" />
              {idx === 0 && <div className="absolute inset-0 flex items-center justify-center bg-black/20 text-white font-bold text-[8px]">CAPA</div>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Results;