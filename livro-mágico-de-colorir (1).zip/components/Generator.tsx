import React, { useState, useEffect } from 'react';
import { Sparkles, BookOpen, Palette, PenTool, Smile, Grid3X3, Layers, Layout, Star, Image as ImageIcon, Crown, Settings, SlidersHorizontal, ChevronDown, ChevronUp } from 'lucide-react';

interface GeneratorProps {
  onGenerate: (
    theme: string, 
    name: string, 
    style: string | string[],
    thickness: 'thin' | 'medium' | 'thick',
    reference: string,
    pageCount: number
  ) => void;
  onDraftChange: (
    field: string,
    value: any
  ) => void;
  isGenerating: boolean;
  progress: number;
  error: string | null;
  initialValues?: {
    theme: string;
    childName: string;
    style: string | string[];
    lineThickness?: 'thin' | 'medium' | 'thick';
    referenceInput?: string;
    pageCount?: number;
  };
}

const styles = [
  { 
    id: 'cartoon', 
    label: 'Desenho Animado', 
    icon: Smile,
    description: 'Estilo divertido com formas arredondadas e traços simples.'
  },
  { 
    id: 'realistic', 
    label: 'Realista', 
    icon: PenTool,
    description: 'Desenhos mais detalhados com proporções reais.' 
  },
  { 
    id: 'kawaii', 
    label: 'Fofo / Kawaii', 
    icon: Sparkles,
    description: 'Estilo japonês adorável, olhos grandes e expressões doces.'
  },
  { 
    id: 'pixel', 
    label: 'Pixel Art', 
    icon: Grid3X3,
    description: 'Arte digital retro feita de pixels, como jogos antigos.'
  },
  { 
    id: 'mandala', 
    label: 'Padrões', 
    icon: Palette,
    description: 'Mandalas e formas geométricas intrincadas para relaxar.'
  },
];

const Generator: React.FC<GeneratorProps> = ({ onGenerate, onDraftChange, isGenerating, progress, error, initialValues }) => {
  const [theme, setTheme] = useState(initialValues?.theme || '');
  const [name, setName] = useState(initialValues?.childName || '');
  const [isAdvancedMode, setIsAdvancedMode] = useState(Array.isArray(initialValues?.style));
  const [globalStyle, setGlobalStyle] = useState(
    !Array.isArray(initialValues?.style) ? (initialValues?.style || 'cartoon') : 'cartoon'
  );
  const [pageCount, setPageCount] = useState(initialValues?.pageCount || 6);
  const [pageStyles, setPageStyles] = useState<string[]>(
    Array.isArray(initialValues?.style) 
      ? initialValues.style 
      : Array(12).fill('cartoon') // Support up to 12 pages max locally
  );
  const [thickness, setThickness] = useState<'thin' | 'medium' | 'thick'>(initialValues?.lineThickness || 'medium');
  const [reference, setReference] = useState(initialValues?.referenceInput || '');
  const [showFilters, setShowFilters] = useState(false);

  // Auto-save effect
  useEffect(() => {
    onDraftChange('theme', theme);
    onDraftChange('childName', name);
    onDraftChange('style', isAdvancedMode ? pageStyles.slice(0, pageCount) : globalStyle);
    onDraftChange('lineThickness', thickness);
    onDraftChange('referenceInput', reference);
    onDraftChange('pageCount', pageCount);
  }, [theme, name, globalStyle, pageStyles, thickness, reference, pageCount, isAdvancedMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (theme && name) {
      onGenerate(
        theme, 
        name, 
        isAdvancedMode ? pageStyles.slice(0, pageCount) : globalStyle, 
        thickness, 
        reference,
        pageCount
      );
    }
  };

  const updatePageStyle = (index: number, styleId: string) => {
    const newStyles = [...pageStyles];
    newStyles[index] = styleId;
    setPageStyles(newStyles);
  };

  if (isGenerating) {
    return (
      <div className="max-w-md mx-auto text-center py-12 px-4">
        <div className="relative w-32 h-32 mx-auto mb-8">
          <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
          <div 
            className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"
          ></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles className="text-indigo-600 animate-pulse" size={32} />
          </div>
        </div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">A criar magia...</h3>
        <p className="text-gray-600 mb-6">Estamos a desenhar a página {Math.floor((progress / 100) * pageCount)} de {pageCount}</p>
        
        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-200 overflow-hidden">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <p className="mt-4 text-sm text-slate-400 italic">Isto pode demorar alguns minutos dependendo do número de páginas.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl border border-indigo-50 p-8 sm:p-12">
      <div className="text-center mb-10">
        <div className="bg-indigo-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-indigo-600">
          <BookOpen size={32} />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Cria o teu Livro de Colorir</h2>
        <p className="text-gray-600">
          Introduz um tema, escolhe o estilo e o nome da criança.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-6">
          <div>
            <label htmlFor="childName" className="block text-sm font-bold text-gray-700 mb-2 ml-1">
              Nome da Criança
            </label>
            <input
              id="childName"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Matilde"
              className="w-full px-6 py-4 rounded-2xl bg-gray-800 text-white placeholder-gray-400 border-2 border-transparent focus:border-indigo-500 focus:bg-gray-900 transition-all outline-none text-lg shadow-inner"
              required
            />
          </div>

          <div>
            <label htmlFor="theme" className="block text-sm font-bold text-gray-700 mb-2 ml-1">
              Tema do Livro
            </label>
            <input
              id="theme"
              type="text"
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
              placeholder="Ex: Dinossauros no Espaço, Princesas Subaquáticas..."
              className="w-full px-6 py-4 rounded-2xl bg-gray-800 text-white placeholder-gray-400 border-2 border-transparent focus:border-indigo-500 focus:bg-gray-900 transition-all outline-none text-lg shadow-inner"
              required
            />
          </div>
        </div>

        {/* Style Selection */}
        <div>
          <div className="flex justify-between items-center mb-4 px-1">
            <label className="block text-sm font-bold text-gray-700">
              Estilo do Desenho
            </label>
            <div className="flex bg-gray-100 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setIsAdvancedMode(false)}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                  !isAdvancedMode ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Uniforme
              </button>
              <button
                type="button"
                onClick={() => setIsAdvancedMode(true)}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-1 ${
                  isAdvancedMode ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <Layers size={12} />
                Misto
              </button>
            </div>
          </div>

          {!isAdvancedMode ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
              {styles.map((style) => {
                const Icon = style.icon;
                const isSelected = globalStyle === style.id;
                return (
                  <button
                    key={style.id}
                    type="button"
                    onClick={() => setGlobalStyle(style.id)}
                    className={`group relative flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all duration-200 ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-sm'
                        : 'border-gray-100 bg-white hover:border-indigo-200 hover:bg-gray-50 text-gray-500'
                    }`}
                  >
                    <Icon size={24} className={`mb-2 ${isSelected ? 'text-indigo-600' : 'text-gray-400'}`} />
                    <span className="text-xs font-bold">{style.label}</span>
                    <div className="absolute bottom-full mb-2 hidden group-hover:block w-40 p-2 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10 pointer-events-none">
                      {style.description}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-300 bg-gray-50 p-4 rounded-2xl border border-gray-100">
              <div className="flex items-center gap-2 text-xs text-indigo-600 font-bold mb-2 bg-indigo-50 p-2 rounded-lg inline-block">
                <Crown size={12} />
                Personalização Avançada ({pageCount} páginas)
              </div>
              {Array.from({ length: pageCount }).map((_, idx) => (
                <div key={idx} className="flex items-center justify-between bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
                  <div className="flex items-center gap-3">
                     <span className="text-xs font-bold text-gray-500 w-16">{idx === 0 ? 'Capa' : `Pág ${idx}`}</span>
                  </div>
                  <select
                    value={pageStyles[idx]}
                    onChange={(e) => updatePageStyle(idx, e.target.value)}
                    className="bg-gray-50 border-2 border-gray-100 text-gray-700 text-sm rounded-lg p-2 outline-none font-semibold hover:bg-gray-100 transition-colors w-full"
                  >
                    {styles.map(s => (
                      <option key={s.id} value={s.id}>{s.label}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* More Filters Accordion */}
        <div className="border border-gray-200 rounded-2xl overflow-hidden">
            <button 
                type="button"
                onClick={() => setShowFilters(!showFilters)}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors text-gray-700 font-bold text-sm"
            >
                <div className="flex items-center gap-2">
                    <SlidersHorizontal size={16} />
                    Mais Opções & Filtros
                </div>
                {showFilters ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            
            {showFilters && (
                <div className="p-4 bg-white space-y-6 animate-in slide-in-from-top-2">
                    {/* Page Count */}
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-xs font-bold text-gray-600">Número de Páginas</label>
                            <span className="bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded text-xs font-bold">{pageCount}</span>
                        </div>
                        <input 
                            type="range" 
                            min="3" 
                            max="12" 
                            value={pageCount} 
                            onChange={(e) => setPageCount(parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                        />
                        <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                            <span>3</span>
                            <span>12</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-gray-100">
                        <div>
                            <label className="block text-xs font-bold text-gray-600 mb-1.5">Espessura da Linha</label>
                            <div className="flex bg-gray-100 p-1 rounded-lg">
                                {(['thin', 'medium', 'thick'] as const).map((t) => (
                                    <button
                                        key={t}
                                        type="button"
                                        onClick={() => setThickness(t)}
                                        className={`flex-1 py-1.5 text-xs font-bold rounded-md capitalize transition-all ${
                                            thickness === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                                        }`}
                                    >
                                        {t === 'thin' ? 'Fina' : t === 'medium' ? 'Média' : 'Grossa'}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label htmlFor="ref" className="block text-xs font-bold text-gray-600 mb-1.5">Contexto Extra (Opcional)</label>
                            <input
                                id="ref"
                                type="text"
                                value={reference}
                                onChange={(e) => setReference(e.target.value)}
                                placeholder="Ex: balões, festa..."
                                className="w-full px-3 py-1.5 text-sm rounded-lg bg-gray-50 border border-gray-200 focus:border-indigo-500 outline-none"
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-xl text-sm border border-red-100">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={!theme || !name}
          className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transform transition hover:-translate-y-1 active:translate-y-0 flex items-center justify-center gap-2 text-lg"
        >
          <Sparkles size={24} />
          Gerar Livro Mágico ({pageCount} Páginas)
        </button>
      </form>
    </div>
  );
};

export default Generator;