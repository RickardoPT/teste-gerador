import React from 'react';
import { BookOpen, Trash2, Calendar } from 'lucide-react';
import { SavedBook } from '../types';

interface LibraryProps {
  books: SavedBook[];
  onLoadBook: (book: SavedBook) => void;
  onDeleteBook: (id: string) => void;
}

const Library: React.FC<LibraryProps> = ({ books, onLoadBook, onDeleteBook }) => {
  if (books.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center px-4">
        <div className="bg-indigo-50 p-6 rounded-full mb-6">
          <BookOpen size={48} className="text-indigo-300" />
        </div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">A Biblioteca está vazia</h3>
        <p className="text-gray-500 max-w-md">
          Ainda não criaste nenhum livro. Vai ao separador "Criar Novo Livro" para começares a tua coleção!
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900">Minha Biblioteca</h2>
        <p className="text-gray-600">Gerir os meus projetos e exemplos.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {books.map((book) => (
          <div 
            key={book.id} 
            className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden group flex flex-col"
          >
            {/* Cover Preview */}
            <div 
              className="aspect-[3/4] bg-gray-100 relative cursor-pointer overflow-hidden"
              onClick={() => onLoadBook(book)}
            >
              {book.pages[0]?.url ? (
                <img 
                  src={book.pages[0].url} 
                  alt={book.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-300">
                  <BookOpen size={40} />
                </div>
              )}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
            </div>

            {/* Info */}
            <div className="p-4 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg text-gray-800 line-clamp-1">{book.title}</h3>
                  <p className="text-sm text-indigo-600 font-medium">{book.childName}</p>
                </div>
              </div>
              
              <div className="mt-auto pt-4 border-t border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <Calendar size={12} />
                  <span>{new Date(book.date).toLocaleDateString()}</span>
                </div>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    if(window.confirm('Tem a certeza que deseja apagar este livro?')) {
                      onDeleteBook(book.id);
                    }
                  }}
                  className="text-gray-400 hover:text-red-500 p-1 rounded-md hover:bg-red-50 transition-colors"
                  title="Apagar Livro"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Library;