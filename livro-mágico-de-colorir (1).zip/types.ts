export interface ColoringPage {
  id: string;
  url: string; // Base64 data URL
  prompt: string;
  isCover: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  notes: string;
  createdAt: string;
}

export interface SavedBook {
  id: string;
  title: string; // Theme
  childName: string;
  date: string;
  pages: ColoringPage[];
  style: string | string[];
  pageCount: number;
}

export type ViewMode = 'generator' | 'library' | 'settings' | 'clients';

export interface AppState {
  currentView: ViewMode;
  savedBooks: SavedBook[];
  clients: Client[];
  // Generator State
  theme: string;
  childName: string;
  style: string | string[];
  pageCount: number;
  isGenerating: boolean;
  pages: ColoringPage[];
  generationProgress: number; // 0 to 100
  error: string | null;
  // Extra inputs
  lineThickness: 'thin' | 'medium' | 'thick';
  referenceInput: string;
}